# Youtube-downloader
It is a simple YouTube downloader which takes URL of the YouTube Video from the user and saves it in your device. Multiple Video downloads at the same time are also supported by this downloader. 

We will be using pytubeX library for our purpose since pytube and pytube3 are now depreciated and will not work. pytube3 has now become pytubeX.

So, you need to use pip install pytubeX for this purpose. Though while importing in the code, we would still write pytube since its thw way it works.

Install from official reprository(to avoid already solved bugs) as of sometimes PIP don't update the libraries that fast
write this command : - 
`python -m pip install git+https://github.com/pytube/pytube`

